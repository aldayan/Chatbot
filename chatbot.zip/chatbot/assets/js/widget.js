// Archivo: chatbot-widget.js
(function () {
    // Crear el contenedor principal del chatbot
    const chatbotButton = document.createElement("button");
    const chatbotContainer = document.createElement("div");

    // Estilos para el botón flotante
    chatbotButton.id = "chatbotButton";
    chatbotButton.innerHTML = "💬";
    chatbotButton.style.position = "fixed";
    chatbotButton.style.bottom = "20px";
    chatbotButton.style.right = "20px";
    chatbotButton.style.backgroundColor = "#007BFF";
    chatbotButton.style.color = "white";
    chatbotButton.style.border = "none";
    chatbotButton.style.borderRadius = "50%";
    chatbotButton.style.width = "60px";
    chatbotButton.style.height = "60px";
    chatbotButton.style.fontSize = "24px";
    chatbotButton.style.cursor = "pointer";
    chatbotButton.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";

    // Estilos para el contenedor del chatbot
    chatbotContainer.id = "chatbotContainer";
    chatbotContainer.style.position = "fixed";
    chatbotContainer.style.bottom = "90px";
    chatbotContainer.style.right = "20px";
    chatbotContainer.style.width = "300px";
    chatbotContainer.style.maxHeight = "400px";
    chatbotContainer.style.backgroundColor = "white";
    chatbotContainer.style.border = "1px solid #ddd";
    chatbotContainer.style.borderRadius = "10px";
    chatbotContainer.style.boxShadow = "0 4px 8px rgba(0, 0, 0, 0.2)";
    chatbotContainer.style.overflow = "hidden";
    chatbotContainer.style.display = "none";
    chatbotContainer.style.flexDirection = "column";
    chatbotContainer.style.zIndex = "1000";

    // Estructura interna del chatbot
    chatbotContainer.innerHTML = `
        <div id="chatbotHeader" style="background-color: #007BFF; color: white; padding: 10px; text-align: center; font-weight: bold;">
            Chatbot
        </div>
        <div id="chatbotMessages" style="flex: 1; padding: 10px; overflow-y: auto; font-family: Arial, sans-serif; font-size: 14px;"></div>
        <div id="chatbotInput" style="display: flex; border-top: 1px solid #ddd;">
            <input type="text" id="userMessage" style="flex: 1; padding: 10px; border: none; outline: none;" placeholder="Escribe un mensaje...">
            <button id="sendButton" style="background-color: #007BFF; color: white; border: none; padding: 10px 15px; cursor: pointer;">Enviar</button>
        </div>
    `;

    // Agregar los elementos al DOM
    document.body.appendChild(chatbotButton);
    document.body.appendChild(chatbotContainer);

    // Lógica del chatbot
    chatbotButton.addEventListener("click", () => {
        chatbotContainer.style.display = chatbotContainer.style.display === "none" ? "flex" : "none";
    });

    const chatbotMessages = chatbotContainer.querySelector("#chatbotMessages");
    const userMessageInput = chatbotContainer.querySelector("#userMessage");
    const sendButton = chatbotContainer.querySelector("#sendButton");

    sendButton.addEventListener("click", sendMessage);
    userMessageInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") sendMessage();
    });

    function sendMessage() {
        const userMessage = userMessageInput.value.trim();
        if (!userMessage) return;

        appendMessage("user", userMessage);
        userMessageInput.value = "";

        fetch("chatbot.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: userMessage }),
        })
            .then((response) => response.json())
            .then((data) => {
                const reply = data.reply || "Lo siento, no entendí eso.";
                appendMessage("bot", reply);
            })
            .catch(() => {
                appendMessage("bot", "Error: No se pudo conectar con el servidor.");
            });
    }

    function appendMessage(sender, text) {
        const messageElement = document.createElement("div");
        messageElement.className = `message ${sender}`;
        messageElement.style.margin = "5px 0";
        messageElement.style.textAlign = sender === "user" ? "right" : "left";
        messageElement.style.color = sender === "user" ? "#007BFF" : "#555";
        messageElement.textContent = text;
        chatbotMessages.appendChild(messageElement);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }
})();
