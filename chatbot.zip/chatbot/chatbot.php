
<?php
require 'vendor/autoload.php';
session_start();
use GuzzleHttp\Client;

// Configura tu API Key de OpenAI
define('OPENAI_API_KEY', 'sk-oLnWyffAtBR17vDdwaUr_68BLYcGhcw2lC6IEc09-4T3BlbkFJpWCKmdj9eK3GONklOl2ZsoNxdeyL6QB3Nu6T0HbL4A');

// Inicializa la bienvenida si no existe historial o se refresca la página
if (!isset($_SESSION['chatHistory']) || isset($_GET['reset'])) {
    $_SESSION['chatHistory'] = [
        ['sender' => 'bot', 'message' => 'Hola 👋¡Bienvenido! ¿Cómo puedo ayudarte hoy?']
    ];
}

function getChatbotResponse($userInput) {
    $client = new Client();
    $response = $client->post('https://api.openai.com/v1/chat/completions', [
        'headers' => [
            'Authorization' => 'Bearer ' . OPENAI_API_KEY,
            'Content-Type' => 'application/json',
        ],
        'json' => [
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                ['role' => 'system', 'content' => 'Eres un chatbot útil.'],
                ['role' => 'user', 'content' => $userInput],
            ],
            'max_tokens' => 100,
            'temperature' => 0.7,
        ],
    ]);
    $body = json_decode($response->getBody(), true);
    return $body['choices'][0]['message']['content'] ?? 'Lo siento, no entendí eso.';
}

$chatHistory = $_SESSION['chatHistory'];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_message'])) {
    header('Content-Type: application/json');
    $userMessage = trim($_POST['user_message']);
    $botResponse = getChatbotResponse($userMessage);

    // Elimina el mensaje de bienvenida si existe
    if (count($chatHistory) > 0 && $chatHistory[0]['sender'] === 'bot' && strpos($chatHistory[0]['message'], 'Bienvenido') !== false) {
        array_shift($chatHistory);
    }

    $chatHistory[] = ['sender' => 'user', 'message' => $userMessage];
    $chatHistory[] = ['sender' => 'bot', 'message' => $botResponse];
    $_SESSION['chatHistory'] = $chatHistory;

    echo json_encode([
        'status' => 'success',
        'user_message' => $userMessage,
        'bot_response' => $botResponse
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatbot</title>
    <style>
        /* Widget Style */
         /* Widget Style */
         body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        .chat-widget { position: fixed; bottom: 20px; right: 20px; width: 350px; background: #fff; border: 1px solid #ccc; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); display: flex; flex-direction: column; z-index: 1000; }
        .chat-header { background: #FF0000; color: white; padding: 10px; border-radius: 10px 10px 0 0; font-weight: bold; display: flex; justify-content: space-between; align-items: center;}
        .chat-messages { padding: 10px; flex: 1; overflow-y: auto; max-height: 300px; display: flex; flex-direction: column; }
        .message { margin: 5px 0; padding: 8px; border-radius: 10px; font-size: 14px; display: inline-block; max-width: 80%; }
        .user { background:rgb(6, 52, 204); color: white; text-align: right; align-self: flex-end; }
        .bot { background: #f1f1f1; color: #333; text-align: left; align-self: flex-start; }
        .chat-input { display: flex; border-top: 1px solid #ccc; padding: 5px; }
        input[type="text"] { flex: 1; padding: 10px; border: 1px solid #ccc; border-radius: 20px; margin-right: 5px; }
        button { background:rgb(37, 134, 12); color: white; border: none; padding: 10px 15px; border-radius: 50%; cursor: pointer; font-size: 16px; }
        button:hover { background: #cc0000; }
        
        /* Floating Icon Style */
        .chat-icon {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 230px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            display: flex;
            align-items: center;
            padding: 10px;
            cursor: pointer;
          
            animation: bounce 1.5s infinite;
        }

        .chat-icon img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
          
        }
        .chat-icon span {
            margin-bottom: 2px;
            margin-top: 5px;
            
        }
        .chat-icon .call-button {
            background: #C20000;
            color: #fff;
            padding: 5px 10px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            gap: 5px;
            margin-top: 5px;
            
            margin-bottom: 2px;
        }
        .chat-icon .call-button:hover {
            background: #A00000;
        }

        .icono{
            margin-left: 0rem;
        }
        .robot{
              margin-left: 5px;
        }
        .guia{
            margin-left: 15px;

        }
      

    

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }
            40% {
                transform: translateY(-10px);
            }
            60% {
                transform: translateY(-5px);
            }
        }

        .hidden { display: none; }

         /* Emoji and Attachments */
         .emoji-button, .attachment-button {

            background: none;
            border: none;
            cursor: pointer;
            font-size: 20px;
            margin: 0 1px;
        }
    </style>
    <script>
        function toggleChat() {
            const widget = document.querySelector('.chat-widget');
            const icon = document.querySelector('.chat-icon');
            widget.classList.toggle('hidden');
            icon.classList.toggle('hidden');
        }

        function sendMessage(event) {
            event.preventDefault();
            const input = document.querySelector('input[name="user_message"]');
            const userMessage = input.value.trim();
            if (!userMessage) return;
            
            const messagesContainer = document.querySelector('.chat-messages');
            const userDiv = document.createElement('div');
            userDiv.className = 'message user';
            userDiv.textContent = userMessage;
            messagesContainer.appendChild(userDiv);
            input.value = '';
            
            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ user_message: userMessage })
            })
            .then(response => response.json())
            .then(data => {
                const botDiv = document.createElement('div');
                botDiv.className = 'message bot';
                botDiv.textContent = data.bot_response;
                messagesContainer.appendChild(botDiv);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            });
        }
        setInterval(() => {
            const chatIcon = document.querySelector('.chat-icon');
            chatIcon.style.animation = ' 1s ';
            setTimeout(() => chatIcon.style.animation = 'none', 1000);
        }, 3000);

        window.onload = function() {
            fetch('?reset=1');
        };
    </script>
</head>
<body>

<!-- Chat Icon -->
<div class="chat-icon" onclick="toggleChat()">
  <span class="robot"> <img src="./assets/img/asistente-de-robot.png" alt=""></span>
    <div class="guia">
        <span>¿Necesitas ayuda?</span>
        <div class="call-button">
            Empezar chat
        </div>
    </div>
</div>

<!-- Chat Widget -->
<div class="chat-widget hidden">
    <div class="chat-header" ><span style="display: flex; justify-content: center; align-items: center;"><img class="icono" src="./assets/img/asistente-de-robot.png" alt="">Atenas-bot</span>
        <span onclick="toggleChat()" style="cursor:pointer; font-size: 1.2rem; margin-right: 1.5rem;">X</span>
    </div>
    <div class="chat-messages">
        <?php foreach ($chatHistory as $entry): ?>
            <div class="message <?= $entry['sender'] ?>">
                <?= htmlspecialchars($entry['message']) ?>
            </div>
        <?php endforeach; ?>
    </div>
    <form onsubmit="sendMessage(event)" class="chat-input">
        <input type="text" name="user_message" placeholder="Escribe tu mensaje..." required>
        <button type="submit" style="font-size: 1.5rem;">></button>
    </form>

</div>

</body>
</html>




















